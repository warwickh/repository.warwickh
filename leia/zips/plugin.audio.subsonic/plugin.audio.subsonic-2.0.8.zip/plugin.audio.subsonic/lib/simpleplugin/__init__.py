#v2.1.0
#https://github.com/romanvm/script.module.simpleplugin/releases

from simpleplugin import *